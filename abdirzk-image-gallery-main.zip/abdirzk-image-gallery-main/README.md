# abdirzk image gallery
 
Image Gallery This is a simple image gallery built using HTML, CSS, and JavaScript. It displays a series of images in a scrollable format with navigation buttons to move between them.

